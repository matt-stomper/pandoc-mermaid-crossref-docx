from typing import Optional, Union
from xml.sax.saxutils import escape

import panflute as pf


TOC_CLASS = "table_of_contents"
DEFAULT_TOC_LEVEL = 1


def toc_field_xml(style_name: str, level: int = DEFAULT_TOC_LEVEL) -> str:
    escaped_style_name = escape(style_name, {'"': "&quot;"})
    instruction = f'TOC \\h \\z \\t "{escaped_style_name},{level}"'

    return f"""
<w:p>
  <w:r>
    <w:fldChar w:fldCharType="begin"/>
  </w:r>
  <w:r>
    <w:instrText xml:space="preserve">{instruction}</w:instrText>
  </w:r>
  <w:r>
    <w:fldChar w:fldCharType="separate"/>
  </w:r>
  <w:r>
    <w:t>Right-click and update field to generate the table of contents.</w:t>
  </w:r>
  <w:r>
    <w:fldChar w:fldCharType="end"/>
  </w:r>
</w:p>
""".strip()


def style_from_attributes(div: pf.Div) -> Optional[str]:
    style = div.attributes.get("style")

    if style:
        return style.strip()

    return None


def style_from_markdown_shortcut(div: pf.Div) -> Optional[str]:
    if div.identifier:
        return div.identifier.strip()

    return None


def style_from_content(div: pf.Div) -> Optional[str]:
    if len(div.content) != 1:
        return None

    block = div.content[0]

    if not isinstance(block, pf.Para):
        return None

    style = pf.stringify(block).strip()

    if style:
        return style

    return None


def style_from_div(div: pf.Div) -> Optional[str]:
    return (
        style_from_attributes(div)
        or style_from_markdown_shortcut(div)
        or style_from_content(div)
    )


def action(
    elem: pf.Element,
    doc: pf.Doc,
) -> Optional[Union[pf.RawBlock, list[pf.Block]]]:
    if not isinstance(elem, pf.Div) or TOC_CLASS not in elem.classes:
        return None

    style_name = style_from_div(elem)

    if not style_name:
        raise ValueError(
            "table_of_contents div requires a style name. "
            "Use :::table_of_contents[Style Name] or "
            '::: {.table_of_contents style="Style Name"}.'
        )

    if doc.format != "docx":
        return []

    return pf.RawBlock(
        toc_field_xml(style_name),
        format="openxml",
    )


def main(doc: Optional[pf.Doc] = None) -> pf.Doc:
    return pf.run_filter(action, doc=doc)


if __name__ == "__main__":
    main()